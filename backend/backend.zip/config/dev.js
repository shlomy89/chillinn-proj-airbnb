module.exports = {
  'dbURL': 'mongodb+srv://shlomy:123@cluster0.4squfus.mongodb.net'
  // 'dbURL': 'mongodb://localhost:27017'
  // 'dbURL': 'mongodb+srv://shlomy:123@cluster0.qbizcld.mongodb.net/?retryWrites=true&w=majority',
}